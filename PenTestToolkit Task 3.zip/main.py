from port_scanner import scan_ports
from brute_forcer import brute_force_login

def main():
    print("=== Penetration Testing Toolkit ===")
    print("1. Port Scanner")
    print("2. Brute Forcer")
    choice = input("Select a module (1 or 2): ")

    if choice == "1":
        target = input("Enter target IP or hostname: ")
        ports = input("Enter ports (comma-separated): ")
        port_list = [int(p.strip()) for p in ports.split(",")]
        scan_ports(target, port_list)
    elif choice == "2":
        target_url = input("Enter login URL: ")
        usernames = ["admin", "user"]
        passwords = ["admin", "password", "123456"]
        brute_force_login(target_url, usernames, passwords)
    else:
        print("Invalid option")

if __name__ == "__main__":
    main()
