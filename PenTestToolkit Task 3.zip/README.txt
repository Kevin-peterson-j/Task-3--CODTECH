Penetration Testing Toolkit
----------------------------

Modules Included:
1. Port Scanner - Scans for open ports on a target host.
2. Brute Forcer - Attempts to brute-force a login form.

Usage:
- Run main.py to access the toolkit interface.
- Use Python 3 and ensure required libraries (requests) are installed.
