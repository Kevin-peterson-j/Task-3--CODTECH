import socket

def scan_ports(host, ports):
    print(f"[+] Scanning {host} for ports: {ports}")
    for port in ports:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((host, port))
            if result == 0:
                print(f"[OPEN] Port {port}")
            sock.close()
        except Exception as e:
            print(f"[ERROR] {e}")
